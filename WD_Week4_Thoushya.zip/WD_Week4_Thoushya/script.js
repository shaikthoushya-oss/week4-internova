const $ = (id) => document.getElementById(id);

/* ========== TASK 1: FUNCTIONS ========== */
// Function declaration with parameters and a return value
function getGrade(percentage) {
  if (percentage >= 75) return "A";
  if (percentage >= 60) return "B";
  if (percentage >= 40) return "C";
  return "Fail";
}

// Multiple functions working together
function calculateResult(m1, m2, m3) {
  const total = m1 + m2 + m3;
  const percentage = (total / 300) * 100;
  return { total, percentage: percentage.toFixed(2), grade: getGrade(percentage) };
}

// Arrow functions (one with a default parameter)
const totalPrice = (price, qty) => price * qty;
const greet = (name = "Student") => `Hello, ${name}! Welcome to Week 4.`;

$("btnResult").addEventListener("click", () => {
  const r = calculateResult(Number($("m1").value), Number($("m2").value), Number($("m3").value));
  $("resultOut").textContent = `Total: ${r.total}/300 | Percentage: ${r.percentage}% | Grade: ${r.grade}`;
});
$("btnPrice").addEventListener("click", () => {
  $("priceOut").textContent = `Total Price: Rs. ${totalPrice(Number($("price").value), Number($("qty").value))}`;
});
$("btnGreet").addEventListener("click", () => {
  $("greetOut").textContent = greet($("gname").value.trim() || undefined);
});

/* ========== TASK 2: ARRAYS ========== */
let students = ["Ravi", "Sita", "Arjun", "Meena", "Kiran"]; // creating an array

function showStudents(message) {
  $("arrList").innerHTML = "";
  students.forEach((name, index) => {           // iterating
    const li = document.createElement("li");
    li.textContent = `${index}: ${name}`;
    $("arrList").appendChild(li);
  });
  $("arrOut").textContent = (message ? message + "\n" : "") +
    `Length: ${students.length} | First: ${students[0]} | Last: ${students[students.length - 1]}`; // accessing
}

$("btnPush").addEventListener("click", () => {
  const name = $("arrInput").value.trim();
  if (!name) return showStudents("Please type a name first.");
  students.push(name);                           // add at end
  $("arrInput").value = "";
  showStudents(`Added ${name} using push()`);
});
$("btnPop").addEventListener("click", () => showStudents(`Removed ${students.pop()} using pop()`));
$("btnShift").addEventListener("click", () => showStudents(`Removed ${students.shift()} using shift()`));
$("btnUpdate").addEventListener("click", () => {
  if (students.length) students[0] = "Updated Name";   // updating
  showStudents("Updated first element");
});
$("btnSort").addEventListener("click", () => { students.sort(); showStudents("Sorted using sort()"); });
$("btnMap").addEventListener("click", () => showStudents("map(): " + students.map(s => s.toUpperCase()).join(", ")));
$("btnFilter").addEventListener("click", () => showStudents("filter(): " + students.filter(s => s.length > 4).join(", ")));
$("btnFind").addEventListener("click", () => showStudents(`indexOf("Sita") = ${students.indexOf("Sita")} | includes: ${students.includes("Sita")}`));
showStudents();

/* ========== TASK 3: OBJECTS ========== */
const student1 = { name: "Ravi", age: 20, course: "Web Development", marks: 85 };
const student2 = { name: "Sita", age: 21, course: "Python", marks: 92 };
const student3 = { name: "Arjun", age: 19, course: "Java", marks: 78 };
const people = [student1, student2, student3];

function showObjects(message) {
  $("objOut").textContent = JSON.stringify(people, null, 2);
  $("objInfo").textContent = message || `Ravi's name is ${student1.name} and he studies ${student1["course"]}.`; // dot and bracket access
}
$("btnObjUpdate").addEventListener("click", () => { student1.marks = 95; showObjects("Updated student1.marks to 95"); });
$("btnObjAdd").addEventListener("click", () => { student1.city = "Vijayawada"; showObjects("Added new property: city"); });
$("btnObjDelete").addEventListener("click", () => { delete student1.age; showObjects("Deleted property: age"); });
$("btnObjValues").addEventListener("click", () => showObjects("Object.values(student2): " + Object.values(student2).join(", ") + "\nObject.keys(student2): " + Object.keys(student2).join(", ")));
showObjects();

/* ========== TASK 4: DOM MANIPULATION ========== */
const domBox = document.querySelector("#domBox");        // selecting elements
let addedCount = 0;

$("btnText").addEventListener("click", () => {
  $("domTitle").textContent = "Text changed using textContent";
});
$("btnHTML").addEventListener("click", () => {
  document.querySelector(".domPara").innerHTML = "This is <b>bold</b> and <i>italic</i> text set using innerHTML.";
});
$("btnStyle").addEventListener("click", () => {
  domBox.style.backgroundColor = "#fef3c7";
  domBox.style.color = "#92400e";
  domBox.style.borderColor = "#f59e0b";
});
$("btnAddEl").addEventListener("click", () => {
  addedCount++;
  const p = document.createElement("p");
  p.className = "added";
  p.textContent = `New paragraph number ${addedCount} added dynamically.`;
  domBox.appendChild(p);
});
$("btnRemoveEl").addEventListener("click", () => {
  const items = domBox.querySelectorAll(".added");
  if (items.length) items[items.length - 1].remove();
});
$("btnReset").addEventListener("click", () => {
  $("domTitle").textContent = "Original Title";
  document.querySelector(".domPara").textContent = "I am a paragraph. Use the buttons to change me.";
  domBox.removeAttribute("style");
  domBox.querySelectorAll(".added").forEach(el => el.remove());
  addedCount = 0;
});

/* ========== TASK 5: EVENTS ========== */
let clicks = 0;
$("btnClick").addEventListener("click", () => { clicks++; $("clickOut").textContent = `Clicks: ${clicks}`; });  // click

$("liveInput").addEventListener("input", (e) => {                                                          // input
  $("liveOut").textContent = `${e.target.value.length} / 40 characters`;
});

$("themeSelect").addEventListener("change", (e) => {                                                      // change
  document.body.className = e.target.value === "light" ? "" : e.target.value;
});

$("contactForm").addEventListener("submit", (e) => {                                                      // submit
  e.preventDefault();
  $("formOut").textContent = `Thanks ${$("fName").value}! We will contact you at ${$("fEmail").value}.`;
  e.target.reset();
});

const hoverBox = $("hoverBox");                                                                           // mouse + keyboard
hoverBox.addEventListener("mouseover", () => { hoverBox.classList.add("hovered"); $("keyOut").textContent = "Mouse is over the box."; });
hoverBox.addEventListener("mouseout", () => { hoverBox.classList.remove("hovered"); $("keyOut").textContent = "Mouse left the box."; });
hoverBox.addEventListener("keydown", (e) => { $("keyOut").textContent = `You pressed the "${e.key}" key.`; });

/* ========== TASK 6: MINI PROJECT - TO-DO LIST ========== */
let todos = [
  { id: 1, text: "Finish Week 4 assignment", priority: "High", done: false },
  { id: 2, text: "Upload project to GitHub", priority: "Medium", done: false }
];
let nextId = 3;

function renderTodos() {
  const filter = $("todoFilter").value;
  const visible = todos.filter(t => filter === "all" || (filter === "done" ? t.done : !t.done));
  $("todoList").innerHTML = "";
  visible.forEach(t => {
    const li = document.createElement("li");
    if (t.done) li.classList.add("done");
    li.innerHTML = `<input type="checkbox" ${t.done ? "checked" : ""} data-id="${t.id}">
      <span class="task-text"></span>
      <span class="tag ${t.priority}">${t.priority}</span>
      <button class="del" data-id="${t.id}">Delete</button>`;
    li.querySelector(".task-text").textContent = t.text;   // textContent keeps user input safe
    $("todoList").appendChild(li);
  });
  const pending = todos.filter(t => !t.done).length;
  $("todoCount").textContent = `${pending} pending, ${todos.length - pending} completed`;
  if (!visible.length) $("todoList").innerHTML = "<li>No tasks here. Add one above.</li>";
}

$("todoForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const text = $("todoInput").value.trim();
  if (!text) return;
  todos.push({ id: nextId++, text, priority: $("todoPriority").value, done: false });
  $("todoInput").value = "";
  renderTodos();
});
$("todoFilter").addEventListener("change", renderTodos);
$("todoList").addEventListener("click", (e) => {            // event delegation
  const id = Number(e.target.dataset.id);
  if (e.target.matches(".del")) todos = todos.filter(t => t.id !== id);
  else if (e.target.matches("input[type=checkbox]")) todos.find(t => t.id === id).done = e.target.checked;
  else return;
  renderTodos();
});
renderTodos();
