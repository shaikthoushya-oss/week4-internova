# Web Development - Week 4 (JavaScript)

Functions, Arrays, Objects, DOM Manipulation, Events and a To-Do List mini project.

## Files
- index.html - page structure for all 6 tasks
- style.css - styling and themes
- script.js - all JavaScript

## Run
Open index.html in any browser.
